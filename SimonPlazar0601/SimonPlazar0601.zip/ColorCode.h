//
// Created by simon on 03/04/2022.
//

#ifndef SIMONPLAZAR0601_COLORCODE_H
#define SIMONPLAZAR0601_COLORCODE_H

enum class ColorCode {
    Red = 31,
    Green = 32,
    Blue = 34,
    Default = 39
};

#endif //SIMONPLAZAR0601_COLORCODE_H
