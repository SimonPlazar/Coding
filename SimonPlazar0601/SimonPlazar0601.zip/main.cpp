#include <iostream>
#include "Canvas.h"
#include "Rectangle.h"
#include "Circle.h"

int main() {
    system(("chcp "s + std::to_string(65001)).c_str());

    Canvas c;
    c.addShape(new Rectangle(ColorCode(ColorCode::Green), 5, 2));
    c.addShape(new Rectangle(ColorCode(ColorCode::Blue), 10, 5));

    c.addShape(new Circle(ColorCode(ColorCode::Green), 8));
    c.addShape(new Circle(ColorCode(ColorCode::Blue), 7));

    c.print();

    return 0;
}
