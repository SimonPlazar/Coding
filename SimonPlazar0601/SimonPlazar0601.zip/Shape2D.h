//
// Created by simon on 03/04/2022.
//

#ifndef SIMONPLAZAR0601_SHAPE2D_H
#define SIMONPLAZAR0601_SHAPE2D_H

#include "ColorCode.h"

class Shape2D {
protected:
    ColorCode color;

public:
    explicit Shape2D(ColorCode color);

    virtual double getSurfaceArea() const;

    virtual void draw() const;
};


#endif //SIMONPLAZAR0601_SHAPE2D_H
