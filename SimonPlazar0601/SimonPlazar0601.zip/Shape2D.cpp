//
// Created by simon on 03/04/2022.
//

#include "Shape2D.h"

Shape2D::Shape2D(ColorCode color) : color(color){
}

double Shape2D::getSurfaceArea() const {
    return 0;
}

void Shape2D::draw() const {
}
