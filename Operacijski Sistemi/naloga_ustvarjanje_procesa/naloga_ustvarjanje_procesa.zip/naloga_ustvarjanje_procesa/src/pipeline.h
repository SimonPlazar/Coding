#ifndef PIPELINE_H_
#define PIPELINE_H_

int execute_pipeline(char*** cmd_list, int input_fd, int output_fd, int err_fd);

#endif //PIPELINE_H_
