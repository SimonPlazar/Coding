#ifndef READ_COMMANDS_H_
#define READ_COMMANDS_H_

char*** read_command_list(int input);

#endif //READ_COMMANDS_H_
