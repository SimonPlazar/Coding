#!/bin/bash
pwd
echo Ok
