#!/bin/bash
echo "..........."
echo Ok
