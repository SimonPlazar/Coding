#!/bin/bash
echo "hello world!!!"
echo "hello world!!!"
echo "hello world!!!"
echo Fail
echo Ok
