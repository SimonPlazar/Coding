#!/bin/bash
echo Ok
echo other things go here
echo Fail
