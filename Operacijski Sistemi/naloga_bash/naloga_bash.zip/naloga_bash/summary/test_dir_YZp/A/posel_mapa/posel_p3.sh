#!/bin/bash
echo 3 >> "/home/simon/Desktop/naloga_bash/summary/test_dir_YZp/flag.out"
echo Ok
