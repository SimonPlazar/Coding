#!/bin/bash
echo 2 >> "/home/simon/Desktop/naloga_bash/summary/test_dir_YZp/flag.out"
echo Ok
