#!/bin/bash
echo 4 >> "/home/simon/Desktop/naloga_bash/summary/test_dir_YZp/flag.out"
echo Ok
