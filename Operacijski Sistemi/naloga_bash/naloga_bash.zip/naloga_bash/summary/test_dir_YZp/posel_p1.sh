#!/bin/bash
echo 1 >> "/home/simon/Desktop/naloga_bash/summary/test_dir_YZp/flag.out"
echo Ok
