# komentar tukaj ne bo na pravem mestu, posel se ne sme zagnati
echo 5 >> "/home/simon/Desktop/naloga_bash/summary/test_dir_YZp/flag.out"
#!/bin/bash 
echo Ok
