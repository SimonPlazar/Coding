#include "threading.h"
#include <stdio.h>



void
threading_setup(struct threading_struct *threading_obj)
{
    // tukaj pripravite nitenje
    // inicializirajte morebitne spremenljivke v podan threading_struct
    printf("threading setup\n");
}

void
handle_in_thread(struct threading_struct *threading_obj, void (*handler_function)(void* args), void* args)
{
    printf("start new thread\n");
    handler_function(args);
}

void
threading_cleanup(struct threading_struct *threading_obj)
{
    printf("threading cleanup\n");
}
