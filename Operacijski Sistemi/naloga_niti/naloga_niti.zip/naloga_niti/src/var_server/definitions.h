#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_

#define CONNECTION_QUEUE_SIZE 10
#define MAX_REQUEST_LEN 16
#define MAX_ERROR_LEN 128
#define MAX_VAR_COUNT 100
#define MAX_NAME_LEN 128
#define SOCKET_PATH "os.socket"

#endif
