#include "Artwork.h"
#include <iostream>
#include <sstream>

Artwork::Artwork() {
    title = "";
    description = "";
    price = 0;
    year = 0;
}

Artwork::Artwork(std::string newTitle, std::string newDescription, double newPrice, int newYear) {
    title = newTitle;
    description = newDescription;
    price = newPrice;
    year = newYear;
}

std::string Artwork::getTitle() const {
    return title;
}

std::string Artwork::getDescription() const {
    return description;
}

double Artwork::getPrice() const {
    return price;
}

int Artwork::getYear() const {
    return year;
}

void Artwork::setTitle(std::string a) {
    title = a;
}

void Artwork::setDescription(std::string b) {
    description = b;
}

void Artwork::setPrice(double c) {
    price = c;
}

void Artwork::setYear(int d) {
    year = d;
}

std::string Artwork::toString() const {
    std::stringstream ss;
    ss << "[" << title << ", " << description << " " << year << " " << price << "$]" << std::endl;
    return ss.str();
}

void Artwork::print() const{
    std::cout << toString() << std::endl;
}


bool Artwork::isExpensive(const Artwork *second) const {
    if (price > second->getPrice())
        return true;
    else
        return false;
}
