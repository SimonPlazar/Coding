#include <stdio.h>

int main(){
	printf("Simon Plazar E1136441");
	return 0;
}
