#include "Conference.h"
#include <utility>
#include <sstream>

Conference::Conference(std::string title, Date startDate, Date endDate) : title(std::move(title)), startDate(startDate), endDate(endDate) {
}

void Conference::addEvent(const Event &event) {
    this->events.push_back(event);
}

std::string Conference::toString() const {
    std::stringstream ss;
    ss << title << std::endl << startDate.toString() << std::endl << endDate.toString();

    for (const auto & event : events) {
        ss << std::endl;
        ss << event.toString();
    }

    return ss.str();
}

