#include "Event.h"

#include <utility>
#include <sstream>

Event::Event(std::string title, std::string description, Person *presenter, Date date) : title(std::move(title)), description(std::move(description)), presenter(presenter), date(date){
}

void Event::addAttendee(Person *person) {
    this->attendees.push_back(person);
}

std::string Event::toString() const{
    std::stringstream ss;
    ss << title << std::endl << description << std::endl << date.toString();
    for (auto attendee : attendees) {
        ss << std::endl;
        ss << attendee->toString();
    }
    return ss.str();
}



