#include <iostream>
#include "Conference.h"
#include "Event.h"
#include "Person.h"
#include "Date.h"

int main() {
    Person osebe[4] {Person("Benayahu", "Nordskov"),Person("Bituin", "Jokinen"),Person("Stewart", "Upton"),Person("Tunde", "Slovak")};

    Conference Lyoness("Lyoness", Date(1, 1, 2016), Date(29, 12, 2016));

    Event FreeMonery("Free Monery", "opis", &osebe[0], Date(19,9,2016));
    Event PasiveIncome("Pasive Income", "opis", &osebe[0], Date(14,12,2016));
    Event MultiplyAllMonery("Multiply All Monery", "opis", &osebe[0], Date(30,4,2016));

    for (int i = 1; i < 4; ++i) {
        FreeMonery.addAttendee(&osebe[i]);
        PasiveIncome.addAttendee(&osebe[i]);
        MultiplyAllMonery.addAttendee(&osebe[i]);
    }

    Lyoness.addEvent(FreeMonery);
    Lyoness.addEvent(PasiveIncome);
    Lyoness.addEvent(MultiplyAllMonery);

    std::cout << Lyoness.toString() << std::endl;
    return 0;
}
